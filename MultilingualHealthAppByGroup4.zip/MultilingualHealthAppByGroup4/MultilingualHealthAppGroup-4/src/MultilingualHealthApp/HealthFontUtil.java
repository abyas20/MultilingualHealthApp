package MultilingualHealthApp;

import java.awt.Font;

public class HealthFontUtil {
    public static final String[] AMHARIC_FONTS = {
        "Ebrima", // Windows 10+ default, best for Amharic
        "Noto Sans Ethiopic", // if installed
        "Abyssinica SIL", // Linux
        "Arial Unicode MS",
        Font.SANS_SERIF
    };

    public static Font getAmharicFont(int style, int size) {
        for (String name : AMHARIC_FONTS) {
            Font font = new Font(name, style, size);
            if (font.canDisplay('\u12A0')) return font;
        }
        return new Font(Font.SANS_SERIF, style, size);
    }
}