package MultilingualHealthApp;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.util.List;
import java.util.ArrayList;
import java.awt.event.*;
import java.io.*;

public class MultilingualHealthApp {
    static JFrame frame;
    static JPanel container;
    static CardLayout layout;
    static boolean isAmharic = false;

    static List<User> users = new ArrayList<>();
    static List<String> savedPlans = new ArrayList<>();
    static JTextArea plansArea = new JTextArea(10, 30);
    static String currentUser = null;

    static Font getHeaderFont() {
        return HealthFontUtil.getAmharicFont(Font.BOLD, 24);
    }
    static Font getBodyFont() {
        return HealthFontUtil.getAmharicFont(Font.PLAIN, 17);
    }

    static Border modernPanelBorder() {
        return new CompoundBorder(
                new DropShadowBorder(),
                new RoundedBorder(22)
        );
    }

    static class DropShadowBorder extends AbstractBorder {
        private static final int SHADOW_SIZE = 12;
        private static final float SHADOW_ALPHA = 0.18f;
        @Override public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int shadowPad = SHADOW_SIZE / 2;
            for (int i = SHADOW_SIZE; i > 0; i--) {
                float alpha = SHADOW_ALPHA * (i / (float) SHADOW_SIZE);
                g2.setColor(new Color(0, 0, 0, Math.round(255 * alpha)));
                g2.drawRoundRect(
                        x + shadowPad - i, y + shadowPad - i,
                        width - 1 + 2 * i - 2 * shadowPad,
                        height - 1 + 2 * i - 2 * shadowPad,
                        32, 32);
            }
            g2.dispose();
        }
        @Override public Insets getBorderInsets(Component c) {
            return new Insets(SHADOW_SIZE, SHADOW_SIZE, SHADOW_SIZE, SHADOW_SIZE);
        }
        @Override public Insets getBorderInsets(Component c, Insets insets) {
            insets.left = insets.right = insets.top = insets.bottom = SHADOW_SIZE;
            return insets;
        }
    }

    static class RoundedBorder extends LineBorder {
        private int arc;
        public RoundedBorder(int arc) {
            super(new Color(210,210,210), 2, true);
            this.arc = arc;
        }
        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(lineColor);
            g2.drawRoundRect(x, y, width-1, height-1, arc, arc);
            g2.dispose();
        }
    }

    static class RoundedButton extends JButton {
        private Color fillColor;
        private Color hoverColor;
        private int arc;
        private boolean hover;
        public RoundedButton(String text, Color fill, int arcR) {
            super(text);
            this.arc = arcR;
            this.fillColor = fill;
            this.hoverColor = fill.darker();
            setOpaque(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setForeground(Color.WHITE);
            setFont(getBodyFont());
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setMargin(new Insets(8, 22, 8, 22));
            addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                public void mouseExited(MouseEvent e) { hover = false; repaint(); }
            });
        }
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(hover ? hoverColor : fillColor);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), arc, arc);
            super.paintComponent(g);
            g2.dispose();
        }
        @Override
        public void paintBorder(Graphics g) {}
        @Override
        public boolean isContentAreaFilled() { return false; }
    }
    static JButton makeAccentButton(String text) {
        return new RoundedButton(text, new Color(39, 174, 96), 18);
    }
    static JButton makeModernButton(String text) {
        return new RoundedButton(text, new Color(52, 152, 219), 18);
    }
    static JButton makeDangerButton(String text) {
        return new RoundedButton(text, new Color(231, 76, 60), 18);
    }
    static JButton makeLangButton() {
        JButton btnLang = new RoundedButton(Lang.langSwitch(), new Color(243, 156, 18), 18);
        btnLang.setForeground(Color.WHITE);
        return btnLang;
    }

    public static void main(String[] args) {
        Font amharicFont = getBodyFont();
        UIManager.put("Label.font", amharicFont);
        UIManager.put("Button.font", amharicFont);
        UIManager.put("TextField.font", amharicFont);
        UIManager.put("TextArea.font", amharicFont);
        UIManager.put("ComboBox.font", amharicFont);
        UIManager.put("PasswordField.font", amharicFont);
        UIManager.put("ToolTip.font", HealthFontUtil.getAmharicFont(Font.PLAIN, 16));

        users = FileStore.loadUsers();
        if (users.isEmpty()) users.add(new User("test", "1234")); // default demo user

        SwingUtilities.invokeLater(() -> {
            frame = new JFrame("Health Management");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(730, 540);
            frame.setBackground(new Color(245, 247, 250));
            frame.setLocationRelativeTo(null);

            container = new JPanel();
            layout = new CardLayout();
            container.setLayout(layout);

            addAllPages();
            frame.setContentPane(container);
            layout.show(container, "Login");
            frame.setVisible(true);
        });
    }
    static void addAllPages() {
        container.removeAll();
        container.add(loginPage(), "Login");
        container.add(signupPage(), "Signup");
        container.add(dashboardPage(), "Dashboard");
        container.add(chatbotPage(), "Chatbot");
        container.add(healthCalcPage(), "HealthCalc");
        container.add(healthPlanPage(), "HealthPlan");
        container.add(savedPlansPage(), "SavedPlans");
        container.revalidate();
        container.repaint();
    }
    static class User {
        String username, password;
        User(String u, String p) { username = u; password = p; }
    }

    static class Lang {
        static String titleLogin() { return isAmharic ? "የጤና አስተዳደር - ግባ" : "Health Management - Login"; }
        static String username() { return isAmharic ? "የተጠቃሚ ስም" : "Username"; }
        static String password() { return isAmharic ? "የይለፍ ቃል" : "Password"; }
        static String login() { return isAmharic ? "ግባ" : "Login"; }
        static String signup() { return isAmharic ? "ተመዝገብ" : "Sign Up"; }
        static String pleaseEnterUserPass() { return isAmharic ? "እባክዎ የተጠቃሚ ስምና የይለፍ ቃል ያስገቡ" : "Please enter username and password"; }
        static String invalidUserPass() { return isAmharic ? "የተቃራኒ የተጠቃሚ ስም ወይም የይለፍ ቃል" : "Invalid username or password"; }
        static String loginSuccess() { return isAmharic ? "በትክክል ገብተዋል" : "Login successful"; }
        static String chooseUser() { return isAmharic ? "የተጠቃሚ ስም ይምረጡ" : "Choose Username"; }
        static String choosePass() { return isAmharic ? "የይለፍ ቃል ይምረጡ" : "Choose Password"; }
        static String signupTaken() { return isAmharic ? "ይህ የተጠቃሚ ስም ቀድሞ ተጠቅመዋል" : "Username already taken"; }
        static String signupSuccess() { return isAmharic ? "በትክክል ተመዝግበዋል። እባክዎ ይግቡ" : "Signup successful! Please login."; }
        static String backToLogin() { return isAmharic ? "ወደ ግባ ተመለስ" : "Back to Login"; }
        static String langSwitch() { return isAmharic ? "English" : "አማርኛ"; }
        static String dashboardTitle() { return isAmharic ? "ወደ የጤና አስተዳደር ዳሽቦርድ እንኳን ደህና መጡ" : "Welcome to Health Management Dashboard"; }
        static String chatbot() { return isAmharic ? "የመጠየቂያ መሣሪያ" : "Chatbot"; }
        static String healthCalc() { return isAmharic ? "የጤና ማስያ መሳሪያ" : "Health Calculator"; }
        static String healthPlan() { return isAmharic ? "የጤና እቅድ" : "Health Plan"; }
        static String savedPlans() { return isAmharic ? "የተቀመጡ እቅዶች" : "Saved Plans"; }
        static String logout() { return isAmharic ? "ውጣ" : "Logout"; }
        static String chatbotTitle() { return isAmharic ? "የጤና መጠየቂያ መሣሪያ" : "Health Chatbot"; }
        static String askHint() { return isAmharic ? "የጤና ጥያቄ ይጻፉ ለምሳሌ፦ BMI ትርጉም, hypertension ትርጉም" : "Type a health question (try: define BMI, define hypertension)"; }
        static String ask() { return isAmharic ? "ጠይቅ" : "Ask"; }
        static String back() { return isAmharic ? "ተመለስ" : "Back"; }
        static String sex() { return isAmharic ? "ፆታ" : "Sex"; }
        static String male() { return isAmharic ? "ወንድ" : "Male"; }
        static String female() { return isAmharic ? "ሴት" : "Female"; }
        static String age() { return isAmharic ? "እድሜ በዓመት" : "Age (years)"; }
        static String height() { return isAmharic ? "ቁመት በሴ.ሜ" : "Height (cm)"; }
        static String weight() { return isAmharic ? "ክብደት በኪ.ግ" : "Weight (kg)"; }
        static String bloodGroup() { return isAmharic ? "የደም ቡድን" : "Blood Group"; }
        static String calc() { return isAmharic ? "ሂሳብ አድርግ" : "Calculate"; }
        static String validNumbers() { return isAmharic ? "እባክዎ ለእድሜ፣ ቁመት እና ክብደት ትክክለኛ ቁጥሮች ያስገቡ" : "Please enter valid numbers for age, height, and weight."; }
        static String positiveNumbers() { return isAmharic ? "እድሜ፣ ቁመት እና ክብደት አዎንታዊ ቁጥሮች መሆን አለቸው።" : "Age, height and weight must be positive numbers."; }
        static String createPlan() { return isAmharic ? "የጤና እቅድ ይፍጠሩ" : "Create Health Plan"; }
        static String planDesc() { return isAmharic ? "የእቅድ መግለጫ" : "Plan Description"; }
        static String planHint() { return isAmharic ? "የጤና እቅድዎን ዝርዝር ያስገቡ" : "Enter your health plan details"; }
        static String date() { return isAmharic ? "ቀን" : "Date"; }
        static String dateHint() { return isAmharic ? "ቀኑን በYYYY-MM-DD ቅርጸት ያስገቡ" : "Enter date in format YYYY-MM-DD"; }
        static String time() { return isAmharic ? "ሰዓት" : "Time"; }
        static String savePlan() { return isAmharic ? "እቅድ አቅርብ" : "Save Plan"; }
        static String pleasePlanDate() { return isAmharic ? "እባክዎ የእቅድ መግለጫና ቀን ያስገቡ" : "Please enter plan description and date."; }
        static String dateFormat() { return isAmharic ? "ቀኑ በYYYY-MM-DD መሆን አለበት" : "Date format must be YYYY-MM-DD."; }
        static String planSaved() { return isAmharic ? "እቅድ ተቀመጠ!" : "Plan saved!"; }
        static String savedHealthPlans() { return isAmharic ? "የተቀመጡ የጤና እቅዶች" : "Saved Health Plans"; }
        static String backToDash() { return isAmharic ? "ወደ ዳሽቦርድ ተመለስ" : "Back to Dashboard"; }
        static String clearPlans() { return isAmharic ? "ሁሉንም እቅዶች አጥፋ" : "Clear All Plans"; }
        static String clearConfirm() { return isAmharic ? "እርግጠኛ ነዎት የተቀመጡትን እቅዶች ሁሉ ማጥፋት ይፈልጋሉ?" : "Are you sure you want to clear all saved plans?"; }
        static String confirmClear() { return isAmharic ? "አረጋግጥ ማጥፋት" : "Confirm Clear"; }
        static String noPlans() { return isAmharic ? "የተቀመጡ እቅዶች የሉም።" : "No saved Plans."; }
        static String[] sexes() { return isAmharic ? new String[]{"ወንድ", "ሴት"} : new String[]{"Male", "Female"}; }
    }

    // --- LOGIN PAGE ---
    static JPanel loginPage() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(242, 246, 252));
        panel.setBorder(modernPanelBorder());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12,12,12,12);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblTitle = new JLabel(Lang.titleLogin());
        lblTitle.setFont(getHeaderFont());
        lblTitle.setForeground(new Color(41, 128, 185));
        JLabel lblUser = new JLabel(Lang.username() + ":");
        JTextField tfUser = new JTextField(15);
        tfUser.setFont(getBodyFont());
        JLabel lblPass = new JLabel(Lang.password() + ":");
        JPasswordField pfPass = new JPasswordField(15);
        pfPass.setFont(getBodyFont());

        JButton btnLogin = makeAccentButton(Lang.login());
        JButton btnSignup = makeModernButton(Lang.signup());
        JLabel msgLabel = new JLabel(" ");
        msgLabel.setFont(getBodyFont());
        msgLabel.setForeground(new Color(192, 57, 43));
        JButton btnLang = makeLangButton();

        btnLang.addActionListener(e -> {
            isAmharic = !isAmharic;
            addAllPages();
            layout.show(container, "Login");
        });

        gbc.gridx=0; gbc.gridy=0; gbc.gridwidth=2;
        panel.add(lblTitle, gbc);

        gbc.gridwidth=1;
        gbc.gridy=1; gbc.gridx=0; panel.add(lblUser, gbc);
        gbc.gridx=1; panel.add(tfUser, gbc);

        gbc.gridy=2; gbc.gridx=0; panel.add(lblPass, gbc);
        gbc.gridx=1; panel.add(pfPass, gbc);

        gbc.gridy=3; gbc.gridx=0; panel.add(btnLogin, gbc);
        gbc.gridx=1; panel.add(btnSignup, gbc);

        gbc.gridy=4; gbc.gridx=0; gbc.gridwidth=2;
        panel.add(msgLabel, gbc);

        gbc.gridy=5; gbc.gridx=0; gbc.gridwidth=2;
        panel.add(btnLang, gbc);

        btnLogin.addActionListener(e -> {
            String user = tfUser.getText().trim();
            String pass = new String(pfPass.getPassword());
            if (user.isEmpty() || pass.isEmpty()) {
                msgLabel.setText(Lang.pleaseEnterUserPass());
                return;
            }
            boolean found = false;
            for (User u : users) {
                if (u.username.equals(user) && u.password.equals(pass)) {
                    found = true;
                    break;
                }
            }
            if (found) {
                msgLabel.setForeground(new Color(39, 174, 96));
                msgLabel.setText(Lang.loginSuccess());
                tfUser.setText("");
                pfPass.setText("");
                currentUser = user;
                savedPlans = FileStore.loadPlans(currentUser);
                layout.show(container, "Dashboard");
            } else {
                msgLabel.setForeground(new Color(192, 57, 43));
                msgLabel.setText(Lang.invalidUserPass());
            }
        });

        btnSignup.addActionListener(e -> {
            tfUser.setText("");
            pfPass.setText("");
            msgLabel.setText(" ");
            layout.show(container, "Signup");
        });
        return panel;
    }

    // --- SIGNUP PAGE ---
    static JPanel signupPage() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(242, 252, 242));
        panel.setBorder(modernPanelBorder());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12,12,12,12);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblTitle = new JLabel(Lang.signup());
        lblTitle.setFont(getHeaderFont());
        lblTitle.setForeground(new Color(41, 128, 185));
        JLabel lblUser = new JLabel(Lang.chooseUser() + ":");
        JTextField tfUser = new JTextField(15);
        tfUser.setFont(getBodyFont());
        JLabel lblPass = new JLabel(Lang.choosePass() + ":");
        JPasswordField pfPass = new JPasswordField(15);
        pfPass.setFont(getBodyFont());

        JButton btnSignup = makeAccentButton(Lang.signup());
        JButton btnBack = makeModernButton(Lang.backToLogin());
        JLabel msgLabel = new JLabel(" ");
        msgLabel.setFont(getBodyFont());
        JButton btnLang = makeLangButton();
        btnLang.addActionListener(e -> {
            isAmharic = !isAmharic;
            addAllPages();
            layout.show(container, "Signup");
        });

        gbc.gridx=0; gbc.gridy=0; gbc.gridwidth=2;
        panel.add(lblTitle, gbc);

        gbc.gridwidth=1;
        gbc.gridy=1; gbc.gridx=0; panel.add(lblUser, gbc);
        gbc.gridx=1; panel.add(tfUser, gbc);

        gbc.gridy=2; gbc.gridx=0; panel.add(lblPass, gbc);
        gbc.gridx=1; panel.add(pfPass, gbc);

        gbc.gridy=3; gbc.gridx=0; panel.add(btnSignup, gbc);
        gbc.gridx=1; panel.add(btnBack, gbc);

        gbc.gridy=4; gbc.gridx=0; gbc.gridwidth=2;
        panel.add(msgLabel, gbc);

        gbc.gridy=5; gbc.gridx=0; gbc.gridwidth=2;
        panel.add(btnLang, gbc);

        btnSignup.addActionListener(e -> {
            String user = tfUser.getText().trim();
            String pass = new String(pfPass.getPassword());
            if (user.isEmpty() || pass.isEmpty()) {
                msgLabel.setText(Lang.pleaseEnterUserPass());
                return;
            }
            for (User u : users) {
                if (u.username.equals(user)) {
                    msgLabel.setText(Lang.signupTaken());
                    return;
                }
            }
            users.add(new User(user, pass));
            FileStore.saveUsers(users); // Save users after signup
            msgLabel.setText(Lang.signupSuccess());
            tfUser.setText("");
            pfPass.setText("");
        });
        btnBack.addActionListener(e -> {
            tfUser.setText("");
            pfPass.setText("");
            msgLabel.setText(" ");
            layout.show(container, "Login");
        });
        return panel;
    }

    // --- DASHBOARD PAGE ---
    static JPanel dashboardPage() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(240, 245, 255));
        panel.setBorder(modernPanelBorder());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(18,18,18,18);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblTitle = new JLabel(Lang.dashboardTitle());
        lblTitle.setFont(getHeaderFont());
        lblTitle.setForeground(new Color(41, 128, 185));

        JButton btnChatbot = makeModernButton(Lang.chatbot());
        JButton btnHealthCalc = makeModernButton(Lang.healthCalc());
        JButton btnHealthPlan = makeModernButton(Lang.healthPlan());
        JButton btnSavedPlans = makeModernButton(Lang.savedPlans());
        JButton btnLogout = makeDangerButton(Lang.logout());
        JButton btnLang = makeLangButton();
        btnLang.addActionListener(e -> {
            isAmharic = !isAmharic;
            addAllPages();
            layout.show(container, "Dashboard");
        });

        gbc.gridx=0; gbc.gridy=0; gbc.gridwidth=2;
        panel.add(lblTitle, gbc);

        gbc.gridwidth=1;
        gbc.gridy=1; gbc.gridx=0; panel.add(btnChatbot, gbc);
        gbc.gridx=1; panel.add(btnHealthCalc, gbc);

        gbc.gridy=2; gbc.gridx=0; panel.add(btnHealthPlan, gbc);
        gbc.gridx=1; panel.add(btnSavedPlans, gbc);

        gbc.gridy=3; gbc.gridx=0; gbc.gridwidth=2;
        panel.add(btnLogout, gbc);

        gbc.gridy=4; gbc.gridx=0; gbc.gridwidth=2;
        panel.add(btnLang, gbc);

        btnChatbot.addActionListener(e -> layout.show(container, "Chatbot"));
        btnHealthCalc.addActionListener(e -> layout.show(container, "HealthCalc"));
        btnHealthPlan.addActionListener(e -> layout.show(container, "HealthPlan"));
        btnSavedPlans.addActionListener(e -> {
            updateSavedPlansArea();
            layout.show(container, "SavedPlans");
        });
        btnLogout.addActionListener(e -> {
            currentUser = null;
            savedPlans.clear();
            layout.show(container, "Login");
        });

        return panel;
    }

    // --- CHATBOT PAGE ---
    static JPanel chatbotPage() {
        JPanel panel = new JPanel(new BorderLayout(10,10));
        panel.setBorder(modernPanelBorder());
        panel.setBackground(new Color(252, 252, 242));
        JLabel lblTitle = new JLabel(Lang.chatbotTitle());
        lblTitle.setFont(getHeaderFont());
        lblTitle.setForeground(new Color(41, 128, 185));
        JTextArea chatArea = new JTextArea();
        chatArea.setFont(getBodyFont());
        chatArea.setEditable(false);
        chatArea.setLineWrap(true);
        chatArea.setWrapStyleWord(true);
        JScrollPane scroll = new JScrollPane(chatArea);
        JTextField inputField = new JTextField();
        inputField.setFont(getBodyFont());
        inputField.setToolTipText(Lang.askHint());
        JButton sendBtn = makeAccentButton(Lang.ask());
        JButton backBtn = makeModernButton(Lang.back());
        JButton btnLang = makeLangButton();
        btnLang.addActionListener(e -> {
            isAmharic = !isAmharic;
            addAllPages();
            layout.show(container, "Chatbot");
        });

        JPanel bottomPanel = new JPanel(new BorderLayout(5,5));
        bottomPanel.add(inputField, BorderLayout.CENTER);
        bottomPanel.add(sendBtn, BorderLayout.EAST);
        JPanel leftPanel = new JPanel(new GridLayout(2,1,2,2));
        leftPanel.setOpaque(false);
        leftPanel.add(backBtn);
        leftPanel.add(btnLang);

        panel.add(lblTitle, BorderLayout.NORTH);
        panel.add(scroll, BorderLayout.CENTER);
        panel.add(bottomPanel, BorderLayout.SOUTH);
        panel.add(leftPanel, BorderLayout.WEST);

        sendBtn.addActionListener(e -> {
            String question = inputField.getText().trim().toLowerCase();
            if (question.isEmpty()) return;
            chatArea.append((isAmharic ? "እርስዎ" : "You") + ": " + inputField.getText() + "\n");
            chatArea.append((isAmharic ? "መሣሪያ" : "Bot") + ": " + getChatbotResponse(question) + "\n\n");
            inputField.setText("");
        });
        backBtn.addActionListener(e -> {
            inputField.setText("");
            chatArea.setText("");
            layout.show(container, "Dashboard");
        });
        return panel;
    }
    static String getChatbotResponse(String input) {
       if (input.contains("define")) {
            if (input.contains("bmi")) {
                return isAmharic ?
                        "BMI በሰው ክብደትና ቁመት መጠን መሰረት የሚገኝ ልኬት ነው። ቀመር፡ BMI = ክብደት(ኪ.ግ)/ቁመት(ሜትር)^2" :
                        "BMI (Body Mass Index) is a value derived from the mass and height of a person. Formula: BMI = weight(kg) / height(m)^2.";
            }
            if (input.contains("hypertension")) {
                return isAmharic ?
                        "Hypertension ማለት ከፍተኛ የደም ግፊት ሲሆን፤ ይህም ለልብ በሽታዎች ያለንን ተጋላጭነት ይጨምራል።" :
                        "Hypertension is high blood pressure, a condition that increases risk of heart diseases.";
            }
            if (input.contains("diabetes")) {
                return isAmharic ?
                        "Diabetes ማለት የደም የስኳር መጠን ከመጠን በላይ ሲሆን የሚከሰት በሽታ ነው።" :
                        "Diabetes is a disease that occurs when blood glucose is too high.";
            }
            if (input.contains("cholesterol")) {
                return isAmharic ?
                        "Cholesterol በደም ውስጥ የሚገኝ ጠቃሚ የሰም ንጥረ ነገር ሲሆን በከፍተኛ መጠን ሲገኝ አደጋ ያስከትላል።" :
                        "Cholesterol is a waxy substance found in your blood, important but high levels are risky.";
            }
            if (input.contains("calorie")) {
                return isAmharic ?
                        "Calorie የኃይል መለኪያ ነው፤ ክብደትን ለመቆጣጠር ካሎሪዎችን ማመጣጠን ወሳኝ ነገር ነው።" :
                        "A calorie is a unit of energy. Managing calories is key to weight control.";
            }
            if (input.contains("heart rate")) {
                return isAmharic ?
                        "Heart rate ማለት በደቂቃ ውስጥ ያለን የልብ ምት ነው።" :
                        "Heart rate is the number of heart beats per minute.";
            }
            return isAmharic ?
                    "ይቅርታ፣ የዚህ ቃል ትርጉም የለኝም።" :
                    "Sorry, I don't have a definition for that term.";
        }
        return isAmharic ?
                "እባክዎ የጤና ጥያቄዎችን 'define' በማለት ይጀምሩ።" :
                "Please ask health-related questions starting with 'define'.";
    }

    // --- HEALTH CALCULATOR PAGE ---
    static JPanel healthCalcPage() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(modernPanelBorder());
        panel.setBackground(new Color(230, 240, 255));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10,10,10,10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblTitle = new JLabel(Lang.healthCalc());
        lblTitle.setFont(getHeaderFont());
        lblTitle.setForeground(new Color(41, 128, 185));
        JLabel lblSex = new JLabel(Lang.sex() + ":");
        JComboBox<String> sexBox = new JComboBox<>(Lang.sexes());
        sexBox.setFont(getBodyFont());
        JLabel lblAge = new JLabel(Lang.age() + ":");
        JTextField ageField = new JTextField();
        ageField.setFont(getBodyFont());
        JLabel lblHeight = new JLabel(Lang.height() + ":");
        JTextField heightField = new JTextField();
        heightField.setFont(getBodyFont());
        JLabel lblWeight = new JLabel(Lang.weight() + ":");
        JTextField weightField = new JTextField();
        weightField.setFont(getBodyFont());
        JLabel lblBloodGroup = new JLabel(Lang.bloodGroup() + ":");
        JComboBox<String> bloodGroupBox = new JComboBox<>(new String[]{"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"});
        bloodGroupBox.setFont(getBodyFont());

        JButton calcBtn = makeAccentButton(Lang.calc());
        JButton backBtn = makeModernButton(Lang.back());
        JButton btnLang = makeLangButton();
        btnLang.addActionListener(e -> {
            isAmharic = !isAmharic;
            addAllPages();
            layout.show(container, "HealthCalc");
        });

        JTextArea resultArea = new JTextArea(8, 30);
        resultArea.setEditable(false);
        resultArea.setLineWrap(true);
        resultArea.setWrapStyleWord(true);
        resultArea.setFont(getBodyFont());
        JScrollPane scroll = new JScrollPane(resultArea);

        gbc.gridx=0; gbc.gridy=0; gbc.gridwidth=2;
        panel.add(lblTitle, gbc);

        int y=1;
        gbc.gridwidth=1;
        gbc.gridx=0; gbc.gridy=y; panel.add(lblSex, gbc);
        gbc.gridx=1; panel.add(sexBox, gbc);
        y++;
        gbc.gridx=0; gbc.gridy=y; panel.add(lblAge, gbc);
        gbc.gridx=1; panel.add(ageField, gbc);
        y++;
        gbc.gridx=0; gbc.gridy=y; panel.add(lblHeight, gbc);
        gbc.gridx=1; panel.add(heightField, gbc);
        y++;
        gbc.gridx=0; gbc.gridy=y; panel.add(lblWeight, gbc);
        gbc.gridx=1; panel.add(weightField, gbc);
        y++;
        gbc.gridx=0; gbc.gridy=y; panel.add(lblBloodGroup, gbc);
        gbc.gridx=1; panel.add(bloodGroupBox, gbc);
        y++;
        gbc.gridx=0; gbc.gridy=y; panel.add(calcBtn, gbc);
        gbc.gridx=1; panel.add(backBtn, gbc);
        y++;
        gbc.gridx=0; gbc.gridy=y; gbc.gridwidth=2;
        panel.add(scroll, gbc);

        gbc.gridy=y+1; gbc.gridx=0; gbc.gridwidth=2;
        panel.add(btnLang, gbc);

        calcBtn.addActionListener(e -> {
            try {
                String sex = (String) sexBox.getSelectedItem();
                int age = Integer.parseInt(ageField.getText().trim());
                double heightCm = Double.parseDouble(heightField.getText().trim());
                double weightKg = Double.parseDouble(weightField.getText().trim());
                String bloodGroup = (String) bloodGroupBox.getSelectedItem();

                if (age <= 0 || heightCm <= 0 || weightKg <= 0) {
                    resultArea.setText(Lang.positiveNumbers());
                    return;
                }

                double heightM = heightCm / 100.0;
                StringBuilder sb = new StringBuilder();

                // BMI
                double bmi = weightKg / (heightM * heightM);
                sb.append((isAmharic ? "BMI: " : "BMI: ") + String.format("%.2f", bmi) + " - " + (isAmharic ? bmiStatusAmharic(bmi) : bmiStatus(bmi)) + "\n");

                // BMR
                double bmr;
                boolean male = sex.toLowerCase().contains(isAmharic ? "ወንድ" : "male");
                if (male) {
                    bmr = 10 * weightKg + 6.25 * heightCm - 5 * age + 5;
                } else {
                    bmr = 10 * weightKg + 6.25 * heightCm - 5 * age - 161;
                }
                sb.append((isAmharic ? " መሰረታዊ የሰውነት ስርዓት ተመን:" : "BMR (Basal Metabolic Rate): ") + String.format("%.0f", bmr) + (isAmharic ? " ካሎሪ/ቀን" : " kcal/day") + "\n");

                // Ideal Weight
                double idealWeight = male ?
                        50 + 2.3 * ((heightCm / 2.54) - 60) :
                        45.5 + 2.3 * ((heightCm / 2.54) - 60);
                sb.append((isAmharic ? "ተመጣጣኝ ክብደት: " : "Ideal Weight: ") + String.format("%.2f", idealWeight) + (isAmharic ? " ኪ.ግ" : " kg") + "\n");

                // Body Fat
                double bodyFat = (1.20 * bmi) + (0.23 * age) - (male ? 16.2 : 5.4);
                sb.append((isAmharic ? "የሰውነት ስብ መጠን: " : "Body Fat Percentage: ") + String.format("%.2f", bodyFat) + "%\n");
       // Waist-to-Height
                double waist = heightCm * 0.5;
                double whr = waist / heightCm;
                sb.append((isAmharic ? "ወገብ ከቁመት ንፅፅር: " : "Waist-to-Height Ratio: ") + String.format("%.2f", whr) + (isAmharic ? " (ተመጣጣኝ ከ0.5 ያነሰ ሲሆን)" : " (Ideal < 0.5)") + "\n");

                // Blood Group Info
                sb.append((isAmharic ? "የደም ዓይነት መረጃ: " : "Blood Group Info: ") + "\n");
                switch (bloodGroup) {
                    case "A+": sb.append(isAmharic ? "A+ የደም ዓይነት የተለመደ እና ከA+ እና AB+ ጋር የሚጣጣም ነው።" : "A+ blood group is common and compatible with A+ and AB+."); break;
                    case "B+": sb.append(isAmharic ? "B+ የደም ዓይነት የተለመደ እና ከB+ እና AB+ ጋር የሚጣጣም ነው።" : "B+ blood group is common and compatible with B+ and AB+."); break;
                    case "AB+": sb.append(isAmharic ? "AB+ ከሁሉም የደም ዓይነት ተቀባይ ነው።" : "AB+ is universal blood acceptor."); break;
                    case "O+": sb.append(isAmharic ? "O+ የተለመደ እና ለሁሉም የደም ዓይነቶች ሰጪ ነው።" : "O+ is common and universal donor to all blood types."); break;
                    default: sb.append(isAmharic ? "ያልተለመደ የደም ዓይነት፤ እባክዎ የደም መለገሻ መመሪያዎችን ይመልከቱ።" : "Rare blood group; please consult blood donation guidelines."); break;
                }
                sb.append("\n");
            
                // MultilingualHealthApp advice
                sb.append((isAmharic ? "\nየጤና ምክር:\n" : "\nHealth Advice:\n"));
                if (bmi < 18.5) {
                    sb.append(isAmharic ? "- ዝቅተኛ ክብደት ነው ያሎት፣ የተመጣጠነ የአመጋገብ ስርዓትን ያዳብሩ።" : "- You are underweight. Consider a balanced diet with more calories.");
                } else if (bmi <= 24.9) {
                    sb.append(isAmharic ? "- ተመጣጣኝ ክብደት ነው ያሎት፣ የዘውትር እንቅስቃሴዎትን እና ጤናማ አመጋገብዎን ይቀጥሉ።" : "- You have a normal weight. Keep up with regular exercise and healthy eating.");
                } else if (bmi <= 29.9) {
                    sb.append(isAmharic ? "- ከመጠን በላይ ክብደት ነው ያሎት፤ የአካል እንቅስቃሴ ያሳድጉ እንዲሁም የአመጋገብ ስርዓትዎን ይቆጣጠሩ።" : "- Overweight. Try to increase physical activity and monitor diet.");
                } else {
                    sb.append(isAmharic ? "- በጣም ከመጠን በላይ የሆነ ክብደት ነው ያሎት፣ የጤና ባለሙያ ያነጋግሩ።" : "- Obese. Consult a healthcare provider.");
                }
                sb.append("\n" + (isAmharic ? "- ዘወትር የልብ እና የደም ዝውውርን የሚያዳብሩ እንቅስቃሴዎችን ያድርጉ\n- በቂ ውሃ ይጠጡ እና በጣም የበሰሉ ምግቦችን አይጠቀሙ" : "- Regular cardiovascular exercise is recommended.\n- Stay hydrated and avoid excessive processed foods."));

                resultArea.setText(sb.toString());

            } catch (NumberFormatException ex) {
                resultArea.setText(Lang.validNumbers());
            }
        });
        backBtn.addActionListener(e -> {
            ageField.setText("");
            heightField.setText("");
            weightField.setText("");
            resultArea.setText("");
            layout.show(container, "Dashboard");
        });
        return panel;
    }
    static String bmiStatus(double bmi) {
        if (bmi < 18.5) return "Underweight";
        if (bmi <= 24.9) return "Normal weight";
        if (bmi <= 29.9) return "Overweight";
        return "Obese";
    }
    static String bmiStatusAmharic(double bmi) {
        if (bmi < 18.5) return "ዝቅተኛ ክብደት";
        if (bmi <= 24.9) return "መደበኛ ክብደት";
        if (bmi <= 29.9) return "ከመጠን በላይ ክብደት";
        return "በጣም ከመጠን በላይ የሆነ ክብደት";
    }


    // --- HEALTH PLAN PAGE ---
   static JPanel healthPlanPage() {
    JPanel panel = new JPanel(new GridBagLayout());
    panel.setBorder(modernPanelBorder());
    panel.setBackground(new Color(255, 230, 230));
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(12,12,12,12);
    gbc.fill = GridBagConstraints.HORIZONTAL;

    JLabel lblTitle = new JLabel(Lang.createPlan());
    lblTitle.setFont(getHeaderFont());
    lblTitle.setForeground(new Color(41, 128, 185));
    JLabel lblPlan = new JLabel(Lang.planDesc() + ":");
    JTextField planField = new JTextField(20);
    planField.setFont(getBodyFont());
    planField.setToolTipText(Lang.planHint());

    JLabel lblDate = new JLabel(Lang.date() + ":");

    // --- Year, Month, Day dropdowns ---
    java.util.Calendar today = java.util.Calendar.getInstance();
    int thisYear = today.get(java.util.Calendar.YEAR);
    int thisMonth = today.get(java.util.Calendar.MONTH);
    int thisDay = today.get(java.util.Calendar.DAY_OF_MONTH);

    JComboBox<Integer> yearBox = new JComboBox<>();
    for (int y = thisYear; y <= thisYear+100; y++) yearBox.addItem(y);

    JComboBox<Integer> monthBox = new JComboBox<>();
    for (int m = 1; m <= 12; m++) monthBox.addItem(m);

    JComboBox<Integer> dayBox = new JComboBox<>();
    // Helper method to update days based on selected year/month
    Runnable updateDays = () -> {
        int year = (Integer) yearBox.getSelectedItem();
        int month = (Integer) monthBox.getSelectedItem();
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.set(year, month - 1, 1);
        int maxDay = cal.getActualMaximum(java.util.Calendar.DAY_OF_MONTH);
        int selectedDay = dayBox.getItemCount() > 0 ? (Integer) dayBox.getSelectedItem() : 1;
        dayBox.removeAllItems();
        for (int d = 1; d <= maxDay; d++) {
            // If this is current year/month, don't allow days before today
            if (year == thisYear && month == thisMonth+1 && d < thisDay) continue;
            dayBox.addItem(d);
        }
        if (dayBox.getItemCount() > 0) {
            if (selectedDay >= (Integer) dayBox.getItemAt(0) && selectedDay <= (Integer) dayBox.getItemAt(dayBox.getItemCount()-1)) {
                dayBox.setSelectedItem(selectedDay);
            }
        }
    };
    yearBox.addActionListener(e -> updateDays.run());
    monthBox.addActionListener(e -> updateDays.run());
    updateDays.run();

    JLabel lblTime = new JLabel(Lang.time() + ":");
    JComboBox<String> hourBox = new JComboBox<>();
    for (int i=1; i<=12; i++) hourBox.addItem(String.format("%02d", i));
    JComboBox<String> minuteBox = new JComboBox<>();
    for (int i=0; i<60; i+=5) minuteBox.addItem(String.format("%02d", i));
    JComboBox<String> ampmBox = new JComboBox<>(new String[]{"AM", "PM"});
    hourBox.setFont(getBodyFont());
    minuteBox.setFont(getBodyFont());
    ampmBox.setFont(getBodyFont());

    JButton btnSave = makeAccentButton(Lang.savePlan());
    JButton btnBack = makeModernButton(Lang.back());
    JButton btnLang = makeLangButton();
    btnLang.addActionListener(e -> {
        isAmharic = !isAmharic;
        addAllPages();
        layout.show(container, "HealthPlan");
    });

    JLabel msgLabel = new JLabel(" ");
    msgLabel.setFont(getBodyFont());

    gbc.gridx=0; gbc.gridy=0; gbc.gridwidth=2;
    panel.add(lblTitle, gbc);
    gbc.gridwidth=1;
    gbc.gridy=1; gbc.gridx=0; panel.add(lblPlan, gbc);
    gbc.gridx=1; panel.add(planField, gbc);
    gbc.gridy=2; gbc.gridx=0; panel.add(lblDate, gbc);

    JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 2,0));
    datePanel.setBackground(new Color(255, 230, 230));
    datePanel.add(yearBox);
    datePanel.add(new JLabel("-"));
    datePanel.add(monthBox);
    datePanel.add(new JLabel("-"));
    datePanel.add(dayBox);
    gbc.gridx=1; panel.add(datePanel, gbc);

    gbc.gridy=3; gbc.gridx=0; panel.add(lblTime, gbc);
    JPanel timePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 2,0));
    timePanel.setBackground(new Color(255, 230, 230));
    timePanel.add(hourBox);
    timePanel.add(new JLabel(":"));
    timePanel.add(minuteBox);
    timePanel.add(ampmBox);
    gbc.gridx=1; panel.add(timePanel, gbc);
    gbc.gridy=4; gbc.gridx=0; panel.add(btnSave, gbc);
    gbc.gridx=1; panel.add(btnBack, gbc);
    gbc.gridy=5; gbc.gridx=0; gbc.gridwidth=2; panel.add(msgLabel, gbc);
    gbc.gridy=6; gbc.gridx=0; gbc.gridwidth=2; panel.add(btnLang, gbc);

    btnSave.addActionListener(e -> {
        String planDesc = planField.getText().trim();
        Integer year = (Integer) yearBox.getSelectedItem();
        Integer month = (Integer) monthBox.getSelectedItem();
        Integer day = (Integer) dayBox.getSelectedItem();
        String date = (year != null && month != null && day != null)
            ? String.format("%04d-%02d-%02d", year, month, day)
            : "";

        String time = hourBox.getSelectedItem() + ":" + minuteBox.getSelectedItem() + " " + ampmBox.getSelectedItem();
        if (planDesc.isEmpty() || date.isEmpty()) {
            msgLabel.setForeground(new Color(192, 57, 43));
            msgLabel.setText(Lang.pleasePlanDate());
            return;
        }
        String fullPlan = planDesc + " | " + Lang.date() + ": " + date + " | " + Lang.time() + ": " + time;
        savedPlans.add(fullPlan);
        FileStore.savePlans(currentUser, savedPlans);
        msgLabel.setForeground(new Color(39, 174, 96));
        msgLabel.setText(Lang.planSaved());
        planField.setText("");
        // Reset date to today
        yearBox.setSelectedItem(thisYear);
        monthBox.setSelectedItem(thisMonth+1);
        updateDays.run();
        dayBox.setSelectedItem(thisDay);
    });

    btnBack.addActionListener(e -> {
        planField.setText("");
        // Reset date to today
        yearBox.setSelectedItem(thisYear);
        monthBox.setSelectedItem(thisMonth+1);
        updateDays.run();
        dayBox.setSelectedItem(thisDay);
        msgLabel.setText(" ");
        layout.show(container, "Dashboard");
    });

    return panel;
}

    // --- SAVED PLANS PAGE ---
    static JPanel savedPlansPage() {
        JPanel panel = new JPanel(new BorderLayout(10,10));
        panel.setBorder(modernPanelBorder());
        panel.setBackground(new Color(245, 255, 245));
        JLabel lblTitle = new JLabel(Lang.savedHealthPlans());
        lblTitle.setFont(getHeaderFont());
        lblTitle.setForeground(new Color(41, 128, 185));
        plansArea.setEditable(false);
        plansArea.setLineWrap(true);
        plansArea.setWrapStyleWord(true);
        plansArea.setFont(getBodyFont());
        JScrollPane scroll = new JScrollPane(plansArea);

        JButton btnBack = makeModernButton(Lang.backToDash());
        JButton btnClear = makeDangerButton(Lang.clearPlans());
        JButton btnLang = makeLangButton();
        btnLang.addActionListener(e -> {
            isAmharic = !isAmharic;
            addAllPages();
            updateSavedPlansArea();
            layout.show(container, "SavedPlans");
        });
        JPanel bottomPanel = new JPanel();
        bottomPanel.setOpaque(false);
        bottomPanel.add(btnClear);
        bottomPanel.add(btnBack);
        bottomPanel.add(btnLang);

        panel.add(lblTitle, BorderLayout.NORTH);
        panel.add(scroll, BorderLayout.CENTER);
        panel.add(bottomPanel, BorderLayout.SOUTH);

        btnBack.addActionListener(e -> layout.show(container, "Dashboard"));
        btnClear.addActionListener(e -> {
            int confirmed = JOptionPane.showConfirmDialog(frame,
                    Lang.clearConfirm(),
                    Lang.confirmClear(),
                    JOptionPane.YES_NO_OPTION);
            if (confirmed == JOptionPane.YES_OPTION) {
                savedPlans.clear();
                FileStore.savePlans(currentUser, savedPlans);
                updateSavedPlansArea();
            }
        });
        return panel;
    }

    static void updateSavedPlansArea() {
        plansArea.setFont(getBodyFont());
        if (savedPlans.isEmpty()) {
            plansArea.setText(Lang.noPlans());
        } else {
            StringBuilder sb = new StringBuilder();
            for (int i=0; i<savedPlans.size(); i++) {
                sb.append((i+1) + ". " + savedPlans.get(i) + "\n");
            }
            plansArea.setText(sb.toString());
        }
    }
}