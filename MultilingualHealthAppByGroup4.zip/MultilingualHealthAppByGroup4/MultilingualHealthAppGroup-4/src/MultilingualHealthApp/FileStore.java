/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MultilingualHealthApp;

/**
 *
 * @author HP
 */

import java.io.*;
import java.util.*;

public class FileStore {
    private static final String USER_FILE = "users.txt";
    private static final String PLAN_FILE_PREFIX = "plans-";
    private static final String PLAN_FILE_SUFFIX = ".txt";

    // Load users from users.txt
    public static List<MultilingualHealthApp.User> loadUsers() {
        List<MultilingualHealthApp.User> users = new ArrayList<>();
        File file = new File(USER_FILE);
        if (!file.exists()) return users;
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] arr = line.split(",", 2);
                if (arr.length == 2) users.add(new MultilingualHealthApp.User(arr[0], arr[1]));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return users;
    }

    // Save users to users.txt
    public static void saveUsers(List<MultilingualHealthApp.User> users) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(USER_FILE))) {
            for (MultilingualHealthApp.User u : users) {
                writer.println(u.username + "," + u.password);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Load plans for a username
    public static List<String> loadPlans(String username) {
        List<String> plans = new ArrayList<>();
        File file = new File(PLAN_FILE_PREFIX + username + PLAN_FILE_SUFFIX);
        if (!file.exists()) return plans;
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                plans.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return plans;
    }

    // Save plans for a username
    public static void savePlans(String username, List<String> plans) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(PLAN_FILE_PREFIX + username + PLAN_FILE_SUFFIX))) {
            for (String plan : plans) {
                writer.println(plan);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}